/*
 * $Id: Accuracy.java 169 2011-03-03 18:45:00Z ahto.truu $
 *
 *
 *
 * Copyright 2008-2011 GuardTime AS
 *
 * This file is part of the GuardTime client SDK.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.guardtime.asn1;

import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;

import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1ParsingException;
import org.bouncycastle.asn1.DERInteger;
import org.bouncycastle.asn1.DERObject;



/**
 * <a target="_blank" href="http://www.ietf.org/rfc/rfc3161.txt">RFC 3161</a>
 * structure {@code Accuracy} ({@code contentInfo.content.encapContentInfo.eContent.accuracy}).
 *
 * <pre>
 * Accuracy ::= SEQUENCE {
 *    seconds INTEGER OPTIONAL,
 *    millis  [0] INTEGER (1..999) OPTIONAL,
 *    micros  [1] INTEGER (1..999) OPTIONAL
 * }
 * </pre>
 *
 * @since 0.4
 */
public final class Accuracy
extends Asn1Wrapper {
	private org.bouncycastle.asn1.tsp.Accuracy accuracy;
	private Integer seconds;
	private Integer millis;
	private Integer micros;



	/**
	 * Parses a DER-encoded {@code Accuracy} out from the given input stream.
	 *
	 * @param in
	 *            the input stream to read data from.
	 * @return the {@code Accuracy} object.
	 * @throws Asn1FormatException
	 *             if the data read from {@code in} does not represent a valid
	 *             {@code Accuracy} object.
	 * @throws IOException
	 *             if {@code in} throws one.
	 */
	public static Accuracy getInstance(InputStream in)
	throws Asn1FormatException, IOException {
		if (in == null) {
			throw new IllegalArgumentException("invalid input stream: null");
		}

		try {
			DERObject obj = new ASN1InputStream(in).readObject();
			return new Accuracy(obj);
		} catch (ASN1ParsingException e) {
			throw new Asn1FormatException("accuracy has invalid format", e);
		} catch (EOFException e) {
			throw new Asn1FormatException("accuracy has invalid format", e);
		} catch (IllegalStateException e) {
			throw new Asn1FormatException("accuracy has invalid format", e);
		}
	}



	/**
	 * Returns the DER representation of the {@code Accuracy}.
	 *
	 * @return a DER byte array, or {@code null} on error.
	 */
	public byte[] getDerEncoded() {
		return accuracy.getDEREncoded();
	}



	/**
	 * Returns the full seconds value of the accuracy. Note that this can be
	 * {@code null} which should be treated as zero.
	 * <p>
	 * The total tolerance represented by this structure is
	 * {@code (seconds + 0.001 * millis + 0.000001 * micros)} seconds.
	 *
	 * @return the full seconds part of accuracy.
	 */
	public Integer getSeconds() {
		return seconds;
	}

	/**
	 * Returns the milliseconds value of the accuracy. Note that this can be
	 * {@code null} which should be treated as zero.
	 * <p>
	 * The total tolerance represented by this structure is
	 * {@code (seconds + 0.001 * millis + 0.000001 * micros)} seconds.
	 *
	 * @return the milliseconds part of accuracy.
	 */
	public Integer getMillis() {
		return millis;
	}

	/**
	 * Returns the microseconds value of the accuracy. Note that this can be
	 * {@code null} which should be treated as zero.
	 * <p>
	 * The total tolerance represented by this structure is
	 * {@code (seconds + 0.001 * millis + 0.000001 * micros)} seconds.
	 *
	 * @return the microseconds part of accuracy.
	 */
	public Integer getMicros() {
		return micros;
	}



	/**
	 * Class constructor.
	 *
	 * @param obj ASN.1 representation of the timestamp accuracy.
	 *
	 * @throws Asn1FormatException if provided ASN.1 object has invalid format.
	 */
	Accuracy(ASN1Encodable obj)
	throws Asn1FormatException {
		try {
			accuracy = org.bouncycastle.asn1.tsp.Accuracy.getInstance(obj);

			DERInteger sec = accuracy.getSeconds();
			if (sec == null) {
				seconds = null;
			} else {
				int n = sec.getValue().intValue();
				if (n < 0) {
					throw new Asn1FormatException("invalid seconds value: " + n);
				}
				seconds = new Integer(n);
			}

			DERInteger mls = accuracy.getMillis();
			if (mls == null) {
				millis = null;
			} else {
				int n = mls.getValue().intValue();
				if (n < 1 || n > 999) {
					throw new Asn1FormatException("invalid millis value: " + n);
				}
				millis = new Integer(n);
			}

			DERInteger mcs = accuracy.getMicros();
			if (mcs == null) {
				micros = null;
			} else {
				int n = mcs.getValue().intValue();
				if (n < 1 || n > 999) {
					throw new Asn1FormatException("invalid micros value: " + n);
				}
				micros = new Integer(n);
			}
		} catch (Asn1FormatException e) {
			throw e;
		} catch (Exception e) {
			throw new Asn1FormatException("accuracy has invalid format", e);
		}
	}
}
